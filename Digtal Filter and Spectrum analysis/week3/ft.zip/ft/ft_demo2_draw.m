function ft_demo2_draw(t,xn,Ts)

N = length(xn);       % Number of samples
Fs = 1/Ts;

hold off

minx = min(xn);
maxx = max(xn);
range = maxx-minx;
minx = minx - 0.1*range;
maxx = maxx + 0.1*range;
% Plot single period
subplot(2,1,1);
hold off
plot(t,xn);
axis([min(t), max(t), minx,maxx]);
xlabel('Time (s)');
ylabel('Amplitude');

% Approximate Fourier Transform using DFT
Xk = fft(xn);         % Calculate FFT
Xk = fftshift(Xk);    % Shift to put k=0 term in the middle
k = ( (0:N-1) -N/2);  
f = k * Fs / N;           % Frequencies

% Plot FFT
subplot(2,1,2);
hold off
plot(f, Ts*abs(Xk));
axis([-5,5,0,max(Ts*abs(Xk))*1.1])
xlabel('f (Hz)');
ylabel('|Magnitude|');

