% This code generates a single period of a periodic signal and plots the
% signal and FS coefficients.
echo off
disp('T = 1s');
ft_demo1_draw(1, 0.25, 0.0001);
pause
disp('T = 2s');
ft_demo1_draw(2, 0.25, 0.0001);
pause
disp('T = 5s');
ft_demo1_draw(5, 0.25, 0.0001);
pause
disp('T = 10s');
ft_demo1_draw(10, 0.25, 0.0001);
pause
disp('T = 20s');
ft_demo1_draw(20, 0.25, 0.0001);
pause
disp('T = 50s');
ft_demo1_draw(50, 0.25, 0.0001);
