function ft_demo1_draw(T, T1, Ts)
% Draws the Fourier Series for a rectangualr wave with period T and pulse
% length T1. This is approximated by sampling with sampling time Ts

Fs = 1 / Ts;          % Sampling frequency
N = Fs * T;
N1 = Fs * T1;
t = (0:N-1) * Ts;     % Time
F0 = 1/T;             % Fundamental frequency
xn = zeros(N,1);
xn(1:N1) = ones(N1,1);

% Plot single period
subplot(2,2,1);
hold off
plot(t,xn);
axis([0, T, -0.1,1.1]);
xlabel('Time (s)');
ylabel('Amplitude');

% Plot part of period
subplot(2,2,2);
hold off
plot(t,xn);
axis([0, T1*2, -0.1,1.1]);
xlabel('Time (s)');
ylabel('Amplitude');

% Estimate FS using DFT
Xk = fft(xn);         % Calculate FFT
Xk = fftshift(Xk);    % Shift to put k=0 term in the middle
Xk = Xk / N;          % Scale to correspond to FS coeficients
k = ( (0:N-1) -N/2);  % FS coeficient number index

klimit = 10*T;
% Plot FFT
subplot(2,2,3);
hold off
stem(k, abs(Xk));
axis([-klimit,klimit,0,max(abs(Xk))*1.1])
xlabel('k');
ylabel('Magnitude Xk');

% Plot FFT
f = k * F0;           % Frequencies
subplot(2,2,4);
hold off
stem(f, T*abs(Xk));
axis([-10,10,0,max(T*abs(Xk))*1.1])
xlabel('f (Hz)');
ylabel('Magnitude  T*Xk');

