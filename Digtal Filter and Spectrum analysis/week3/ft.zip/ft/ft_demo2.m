echo off

Tmin = -5;  
Tmax = 5;
Ts = 0.0001;  % Sampling time
t = Tmin:Ts:Tmax;

disp('Rectangular pulse');
xn = rectpuls(t,2);
ft_demo2_draw(t, xn, Ts);
pause
disp('Triangular pulse');
xn = tripuls(t,2);
ft_demo2_draw(t, xn, Ts);
pause
disp('Triangular pulse');
xn = tripuls(t,2,-0.8);
ft_demo2_draw(t, xn, Ts);
pause
disp('Gaussian pulse');
xn = exp(-2*t.*t);              % Gaussian pulse
ft_demo2_draw(t, xn, Ts);
pause
disp('Modulated Gaussian pulse');
xn = gauspuls(t,1,0.25);        % Modulated gaussian pulse
ft_demo2_draw(t, xn, Ts);
pause
disp('Impulse function');
N = length(t);
xn = zeros(N,1); xn( (N+1)/2 ) = 1;  % Impulse function
ft_demo2_draw(t, xn, Ts);
pause
disp('Sinc function');
xn = sin(2*pi*t) ./ (2*pi*t); xn( (N+1)/2 ) = 1; % sinc function
ft_demo2_draw(t, xn, Ts);
pause

% Periodic signals
disp('Sin function');
xn = sin(2*pi*t);
ft_demo2_draw(t, xn, Ts);
pause
disp('Square');
xn = square(2*pi*t);             % Periodic square wave
ft_demo2_draw(t, xn, Ts);
pause
disp('Sawtooth');
xn = sawtooth(2*pi*t,0.8);       % Periodic Sawtooth
ft_demo2_draw(t, xn, Ts);
pause
disp('Pulsetrain');
d = [-5:5]; xn = pulstran(t, d, 'rectpuls', 0.01);   % Impulse train
ft_demo2_draw(t, xn, Ts);
pause

% Other
disp('Gaussian noise');
xn = randn(N,1);                 % Gaussian noise
ft_demo2_draw(t, xn, Ts);

