b1 = [1, -sqrt(2), 1]
a1 = [1, -0.9*sqrt(2), 0.81]
b2 = b1
a2 = [1, -1.1*sqrt(2), 1.21]
plot_filter(b1,a1);
pause
plot_filter(b2,a2);
