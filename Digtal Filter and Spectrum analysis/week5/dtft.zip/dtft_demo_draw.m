function dtft_demo_draw(t, xn, Tmin, Tmax )

hold off
subplot(2,1,1);
hold off
stem(t,xn);
minx = min(xn);
maxx = max(xn);
range = maxx-minx;
minx = minx - 0.1*range;
maxx = maxx + 0.1*range;
axis([Tmin, Tmax, minx,maxx]);
xlabel('Time (s)');
ylabel('Amplitude');

Xk = fft(xn);         % Calculate FFT
Nsamples = length(xn);
Omega = (0:Nsamples-1) * 2*pi / Nsamples;
% Plot FFT
subplot(2,1,2);
hold off
plot(Omega, abs(Xk));
axis([0,2*pi,0,max(abs(Xk))*1.1])
xlabel('Omega (radians)');
ylabel('Magnitude');


