% Examples of diffeerent signals and DTFTs

Ts = 1;
Nmin = -500;
Nmax = +500;
n = Nmin:Nmax;
t = n * Ts;
N = length(t);

Width = Ts * 25.1;
Tmin = -5*Width;
Tmax = 5*Width;

disp('Rectangular pulse');
xn = rectpuls(t,Width);
dtft_demo_draw(t,xn,Tmin,Tmax);
pause
disp('Triangular pulse');
xn = tripuls(t,Width);
dtft_demo_draw(t,xn,Tmin,Tmax);
pause
disp('Triangular pulse');
xn = tripuls(t,Width,-0.8);
dtft_demo_draw(t,xn,Tmin,Tmax);
pause
disp('Guassian shaped pulse');
xn = exp(-t.*t/(2*Width*Width));              
dtft_demo_draw(t,xn,Tmin,Tmax);
pause
disp('Modulated Guassian pulse');
xn = gauspuls(t,0.1,2/Width);        
dtft_demo_draw(t,xn,Tmin,Tmax);
pause
disp('Impulse function');
xn = zeros(N,1); xn((N+1)/2) = 1; 
dtft_demo_draw(t,xn,Tmin,Tmax);
pause
disp('Sinc function');
xn = sin(2*0.1*pi*t) ./ (2*0.1*pi*t); xn((N+1)/2) = 1; % sinc function
dtft_demo_draw(t,xn,Tmin,Tmax);
