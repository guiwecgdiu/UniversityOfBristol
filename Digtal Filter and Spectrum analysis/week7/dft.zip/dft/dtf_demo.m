% Examples of diffeerent signals and DFTs

Nmax = 512;
n=0:Nmax-1,

Width = 50.1;
offset = Nmax/2;

% Width = 50.1;
% disp('Rectangular pulse');
% xn = rectpuls(n-offset,Width);
% dft_demo_draw(xn);
% pause
% Width = 20.1;
% disp('Rectangular pulse');
% xn = rectpuls(n-offset,Width);
% dft_demo_draw(xn);
% pause
% Width = 10.1;
% disp('Rectangular pulse');
% xn = rectpuls(n-offset,Width);
% dft_demo_draw(xn);
% pause
%Width = 50.1;
%disp('Triangular pulse');
%xn = tripuls(n-offset,Width);
%dft_demo_draw(xn);
%pause
%disp('Triangular pulse');
%xn = tripuls(n-offset,Width,-0.8);
%dft_demo_draw(xn);
%pause
% Width = 50;
% disp('Guassian shaped pulse');
% xn = exp(-(n-offset).*(n-offset)/(2*Width*Width));              % Gaussian pulse
% dft_demo_draw(xn);
% pause
% Width = 20;
% disp('Guassian shaped pulse');
% xn = exp(-(n-offset).*(n-offset)/(2*Width*Width));              % Gaussian pulse
% dft_demo_draw(xn);
% pause
% Width = 10;
% disp('Guassian shaped pulse');
% xn = exp(-(n-offset).*(n-offset)/(2*Width*Width));              % Gaussian pulse
% dft_demo_draw(xn);
% pause
% Width = 5;
% disp('Guassian shaped pulse');
% xn = exp(-(n-offset).*(n-offset)/(2*Width*Width));              % Gaussian pulse
% dft_demo_draw(xn);
% pause
% Width = 2;
% disp('Guassian shaped pulse');
% xn = exp(-(n-offset).*(n-offset)/(2*Width*Width));              % Gaussian pulse
% dft_demo_draw(xn);
% pause
% Width = 1;
% disp('Guassian shaped pulse');
% xn = exp(-(n-offset).*(n-offset)/(2*Width*Width));              % Gaussian pulse
% dft_demo_draw(xn);
% pause
% disp('Impulse function');
% xn = zeros(Nmax,1); xn(offset) = 1;  % Impulse function
% dft_demo_draw(xn);
% pause
% Width = 50;
% disp('Modulated Guassian pulse');
% xn = gauspuls((n-offset),0.1,2/Width);        % Modulated gaussian pulse
% dft_demo_draw(xn);
% pause
% Width = 10;
% disp('Modulated Guassian pulse');
% xn = gauspuls((n-offset),0.1,2/Width);        % Modulated gaussian pulse
% dft_demo_draw(xn);
% pause
% Width = 2;
% disp('Modulated Guassian pulse');
% xn = gauspuls((n-offset),0.1,2/Width);        % Modulated gaussian pulse
% dft_demo_draw(xn);
% pause
% Width = 1;
% disp('Modulated Guassian pulse');
% xn = gauspuls((n-offset),0.1,2/Width);        % Modulated gaussian pulse
% dft_demo_draw(xn);
% pause
disp('Sinusoid');
Omega =  20*2*pi/Nmax;
xn = sin( Omega * n );
dft_demo_draw(xn);
pause
disp('Sinusoid');
Omega =  20.5*2*pi/Nmax;
xn = sin( Omega * n );
dft_demo_draw(xn);


