function dft_demo_draw( xn )

Nsamples = length(xn);
n = 0:Nsamples-1;
hold off
subplot(2,1,1);
hold off
plot(n,xn);
%minx = min(xn);
%maxx = max(xn);
%range = maxx-minx;
%minx = minx - 0.1*range;
%maxx = maxx + 0.1*range;
%axis([0,Nsamples,minx,maxx]);
xlabel('Sample number n');
ylabel('Amplitude');

Xk = fft(xn);         % Calculate FFT
%Omega = (0:Nsamples-1) * 2*pi / Nsamples;
k = 0:Nsamples-1;
% Plot FFT
subplot(2,1,2);
hold off
plot(k, abs(Xk));
%axis([0,Nsamples,0,max(abs(Xk))*1.1])
xlabel('DFT coef index k');
ylabel('Magnitude');
figure;
plot(k, angle(Xk));



