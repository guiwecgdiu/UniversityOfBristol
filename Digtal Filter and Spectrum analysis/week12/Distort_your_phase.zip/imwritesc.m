function imwritesc(im,name)

    if strcmp(class(im), 'double')
	im = im - min(min(im));       % Offset so that min value is 0.
	im = im./(max(max(im)));      % Rescale so that max is 1.
    end
    imwrite(im,name);