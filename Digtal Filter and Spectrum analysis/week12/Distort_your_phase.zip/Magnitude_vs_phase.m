im1 = imread('akiyo.bmp');
im2 = imread('ostridge.jpg');
im2 = im2(:,1:352);

% im1 = rgb2gray(im1); % convert to greyscale
% im2 = rgb2gray(im2); % convert to greyscale

im1fft = fft2(im1);
im2fft = fft2(im2);

im1phase = angle(im1fft);
im2phase = angle(im2fft);

im1mag = abs(im1fft);
im2mag = abs(im2fft);

newimfft1 = im1mag.*(cos(im2phase) + i*sin(im2phase));
newimfft2 = im2mag.*(cos(im1phase) + i*sin(im1phase));

imwritesc(real(ifft2(newimfft1)), 'im1mag_im2phase.png');
imwritesc(real(ifft2(newimfft2)), 'im1phase_im2mag.png');

im1phaseonly = im1fft./im1mag;
im2phaseonly = im2fft./im2mag;

imwritesc(real(ifft2(im1phaseonly)), 'im1phaseonly.png');
imwritesc(real(ifft2(im2phaseonly)), 'im2phaseonly.png');

imwritesc(im1, 'im1.png');
imwritesc(im2, 'im2.png')